using System;
using System.Windows.Forms;

namespace quizGame
{
    public partial class Form1 : Form
    {
        int correctAnswer;
        int questionNumber = 1;
        int score;
        int percentage;
        int totalQuestions;
        private string tema;

        // Construtor com par�metro
        public Form1(string temas)
        {
            InitializeComponent();
            tema = temas;
            totalQuestions = 8;
            askQuestion(questionNumber);
        }

        // Construtor padr�o (opcional)
        public Form1() : this("Esporte") // Define um tema padr�o
        {
        }

        private void ClickAnswerEvent(object sender, EventArgs e)
        {
            var senderObject = (Button)sender;
            int buttonTag = Convert.ToInt32(senderObject.Tag);

            if (buttonTag == correctAnswer)
            {
                score++;
            }

            if (questionNumber == totalQuestions)
            {
                percentage = (int)Math.Round((double)(100 * score) / totalQuestions);
                MessageBox.Show($"Quiz Encerrado{Environment.NewLine}Voc� respondeu {score} perguntas corretamente{Environment.NewLine}Sua porcentagem total � {percentage} %{Environment.NewLine}Clique em Ok para jogar novamente.");

                score = 0;
                questionNumber = 1; // Reset para 1
                askQuestion(questionNumber);
            }
            else
            {
                questionNumber++;
                askQuestion(questionNumber);
            }
        }

        private void askQuestion(int qnum)
        {
            switch (tema)
            {
                case "Esporte":
                    switch (qnum)
                    {
                        case 1:
                            lblQuestion.Text = "Qual � o maior vencedor da Champions League?";
                            button1.Text = "Barcelona";
                            button2.Text = "Real Madrid";
                            button3.Text = "Milan";
                            button4.Text = "Liverpool";
                            correctAnswer = 2;
                            break;
                        case 2:
                            lblQuestion.Text = "Quantas Copas do Mundo tem o Brasil?";
                            button1.Text = "5";
                            button2.Text = "3";
                            button3.Text = "6";
                            button4.Text = "2";
                            correctAnswer = 1;
                            break;
                            // Adicione mais perguntas de esporte aqui
                    }
                    break;

                case "Filmes":
                    switch (qnum)
                    {
                        case 1:
                            lblQuestion.Text = "Quem � o protagonista de 'O Senhor dos An�is'?";
                            button1.Text = "Frodo";
                            button2.Text = "Gandalf";
                            button3.Text = "Aragorn";
                            button4.Text = "Legolas";
                            correctAnswer = 1;
                            break;
                        case 2:
                            lblQuestion.Text = "Qual � o filme mais lucrativo de todos os tempos?";
                            button1.Text = "Avatar";
                            button2.Text = "Titanic";
                            button3.Text = "Star Wars: O Despertar da For�a";
                            button4.Text = "Vingadores: Ultimato";
                            correctAnswer = 4;
                            break;
                            // Adicione mais perguntas sobre filmes aqui
                    }
                    break;

                case "Tecnologia":
                    switch (qnum)
                    {
                        case 1:
                            lblQuestion.Text = "Qual o melhor professor da UVV?";
                            button1.Text = "C�ssio";
                            button2.Text = "Erlon";
                            button3.Text = "Vin�cius Rosal�n";
                            button4.Text = "Alessandro";
                            correctAnswer = 3;
                            break;
                        case 2:
                            lblQuestion.Text = "Qual o sistema operacional essa imagem representa?";
                            button1.Text = "Linux";
                            button2.Text = "Windows";
                            button3.Text = "GNU";
                            button4.Text = "MAC-OS";
                            correctAnswer = 3;
                            break;
                            // Adicione mais perguntas sobre tecnologia aqui
                    }
                    break;
            }
        }
    }
}
