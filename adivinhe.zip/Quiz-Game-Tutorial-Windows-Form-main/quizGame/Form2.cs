﻿using System;
using System.Windows.Forms;

namespace quizGame
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var form1 = new Form1("Esporte");
            form1.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var form1 = new Form1("Filmes");
            form1.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var form1 = new Form1("Tecnologia");
            form1.Show();
            this.Close();
        }
    }
}
